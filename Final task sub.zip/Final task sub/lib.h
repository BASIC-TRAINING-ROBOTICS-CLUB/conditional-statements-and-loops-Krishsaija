#ifndef FREEFALL_H
#define FREEFALL_H

#include <cmath>    // i included this library to do the square root 

class FreeFall {
public:
    FreeFall(double height, double gravity = 9.8);

    
    double timeOfFall() const;

 
    double finalVelocity() const;

   
    double displacement() const;

private:/*private because public is accecesible by anyone and it is good to
keep your variables private which will be only accecesible by the function*/
    double height;   
    double gravity;  
};

#endif 

