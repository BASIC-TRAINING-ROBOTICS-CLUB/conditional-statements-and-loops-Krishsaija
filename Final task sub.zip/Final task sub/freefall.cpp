#include "FreeFall.h"
#include <stdexcept> /* this is included because if someone puts the height 
in -ve then we need to terminate the code*/

FreeFall::FreeFall(double height, double gravity)
    : height(height), gravity(gravity) {
    if (height < 0) {
        throw std::invalid_argument("Height must be non-negative.");
    }
}

double FreeFall::timeOfFall() const {
    return std::sqrt(2 * height / gravity);
}

double FreeFall::finalVelocity() const {
    return std::sqrt(2 * gravity * height);
}

double FreeFall::displacement() const {
    return height;
}
