#include <iostream>
#include "FreeFall.h"

int main() {
    try {
        double height = 100; // i was going to take height from user once the code works properly
        FreeFall freeFall(height);

        double time = freeFall.timeOfFall();//ALl these
        double velocity = freeFall.finalVelocity();//Three are 
        double displacement = freeFall.displacement();//Called from the
                                                      // Other file
        std::cout << "Time of Fall: " << time << " seconds" << std::endl;
        std::cout << "Final Velocity: " << velocity << " m/s" << std::endl;
        std::cout << "Displacement: " << displacement << " meters" << std::endl;
    } catch (const std::invalid_argument &e) {    //catch is a keyword to handle exception cases
        std::cerr << "Error: " << e.what() << std::endl;//e.what is used to return a string
    }

    return 0;
}
