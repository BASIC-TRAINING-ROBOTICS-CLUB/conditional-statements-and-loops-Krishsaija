/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int a, b, c;
int main()
{
    printf("Enter three sides");
    scanf("%d %d %d", &a, &b, &c);
    if(a==b){
        if(b==c){
            printf("its equilateral");
        }
    }
    else{
        printf("its not");
    }

    return 0;
}
