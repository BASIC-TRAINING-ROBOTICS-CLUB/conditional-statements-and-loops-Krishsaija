#include <stdio.h>
int currentyear = 2024;
int age;
int main() {
	printf("Enter your age -> ");
	scanf("%d",&age);
while(age>0)
{
    age--;
    currentyear--;
}
//	for ( age>=0; currentyear--; age-- )
	{

		printf("Your birth year is -> %d\n", currentyear);
	}


	return 0;
}
