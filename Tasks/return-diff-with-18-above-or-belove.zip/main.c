
#include <stdio.h>
  
int main()
{ 
    int a;
    printf("Enter your age");
    scanf("%d",&a);
        if (a>18)
  {
      printf("ok");
      return 5;
  }
        if (a<18)
        {printf("you are under age");
        return 9;
        }
}
