 # include <stdio.h>
char lr;
int main(){
  printf("Enter letter: ");
  scanf("%c",&lr);
  if (lr == 'a'|| lr == 'A'|| lr == 'e' || lr == 'E'||
         lr == 'i'|| lr == 'I' || lr == 'o'|| lr == 'O'||
         lr == 'u'|| lr == 'U') {
    printf("you entered a vowel ");
   }
   else{
    printf("It is a consonant ");
    }
  return 0;
}
