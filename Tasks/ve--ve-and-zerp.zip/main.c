 # include <stdio.h>
int a;
int main(){
    printf("Enter the value of a: ");
    scanf("%d",&a);
    if (a==0){
        printf("%d is zero", a);
        }
    else if (a>0){
      printf("%d is positive", a);
    }
    else{
      printf("%d is negative", a);
      }
}