# include <stdio.h>
int n = 3;
int main(){
  for(int i = 1; i<=10; i++){
    printf("3 * %d = %d \n", i, 3*i );
  }
}