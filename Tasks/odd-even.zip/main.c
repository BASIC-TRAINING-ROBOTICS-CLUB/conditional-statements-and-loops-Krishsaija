/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int a;
int main()
{
    printf("enter a number");
    scanf("%d",&a);
    if(a%2==0){
        printf("its even");
    }
    else {
        
    printf("its odd");
    }

    return 0;
}