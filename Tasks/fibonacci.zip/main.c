#include <stdio.h>
int a=0;
int b = 1;

int n;
int main(){
  int c = a+b;
  printf("Enter the value of n");
  scanf("%d",&n);
  printf("Fibonacci Series: %d %d ",a , b);
  for(int i=3;i<=n;++i){
    printf("%d ",c);
    a = b;
    b = c;
    c = a+b;
  }
  return 0;
}