 # include <stdio.h>
int yr;
int main(){
  printf("Enter year greater than 2000-");
  scanf("%d",&yr);
  if (yr>2000){
    if(yr%4 == 0){
      printf("Entered year is a leap year");
      }
    else{
      printf("Year is not a leap year");
      }
  }
  else{
    printf("Please enter year more than 2000");
    }
}