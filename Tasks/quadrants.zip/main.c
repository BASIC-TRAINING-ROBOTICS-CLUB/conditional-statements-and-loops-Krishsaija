/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int x,y;
int main(){
    printf("Enter the value of x-");
    scanf("%d", &x);
    printf("Enter the value of y-");
    scanf("%d",&y);
    if (x>0,y>0)
    {
        printf("Its in first quadrant");
    }
    else{
        if (x<0,y>0)
        {printf("its in second quadrant");}
    else{
        if(x<0,y<0)
        {
            printf("its in third quad");
        }
    else{
        if(x>0,y<0){
            
            printf("its in fourth quadrant");
        }
        else { printf("its in the centre");}
    }
    }


        }
    }
