/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int i, sum ;
int main()
{
   int arr[3]={5,6,8};
for(i=0; i<3; i++){
    

    sum += arr[i];
    
}  
printf("sum is %d", sum);
    return 0;
}