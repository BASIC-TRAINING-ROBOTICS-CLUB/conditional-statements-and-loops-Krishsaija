 #include <stdio.h>
int n;
int fact;
int main(){
  printf("Enter no. to make a factorial: ");
  scanf("%d",&n);
  fact = 1;
  for(int i = 1; i<=n;++i){
    fact = fact*(i);
    }
  printf("%d ",fact);
}