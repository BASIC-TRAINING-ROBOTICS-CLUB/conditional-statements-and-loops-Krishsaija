 #include <stdio.h>
int n;
int main(){
  printf("Enter no. to make a factor: ");
  scanf("%d",&n);
  for(int i = 1; i<=n;++i){
    if(n%i == 0){
      printf("%d ", i);
      }
  }
  return 0;
}