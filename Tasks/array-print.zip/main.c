#include<stdio.h>
int main (){
    int arr[7]={7,6,5,4,3,2,1,0};
    //dp[0]=7;
    //dp[1]=6;
    //dp[2]=5;
    //dp[3]=4;
    //dp[4]=3;
    //dp[5]=2;
    //dp[6]=1;
    //dp[7]=0;
for(int i=0;i<=7;i++){
    printf("%d \n",arr[i]);
}
}
