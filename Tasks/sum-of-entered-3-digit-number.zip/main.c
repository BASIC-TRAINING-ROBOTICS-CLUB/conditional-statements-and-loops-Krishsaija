 #include <stdio.h>
int a,sum, rem;
sum = 0;
int main(){
  printf("Enter your number: ");
  scanf("%d", &a);
  while(a>0){
    rem = a%10;
    sum = sum+rem;
    a = a/10;
  }
  printf("Sum = %d ", sum);
}