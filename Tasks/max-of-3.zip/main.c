/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
 # include <stdio.h>
int a,b,c;
int main(){
    printf("Enter the value of a: ");
    scanf("%d",&a);
    printf("Enter the value of b: ");
    scanf("%d",&b);
    printf("Enter the value of c: ");
    scanf("%d",&c);
    if (a>b){
        if (a>c){
            printf("%d is greatest", a);
        }
        else{
            printf("%d is greatest", c);
        }
    }
    else{
        if (b>c){
            printf("%d is greatest",b);
        }
        else{
            printf("%d is greatest", c);
        }
    }
}