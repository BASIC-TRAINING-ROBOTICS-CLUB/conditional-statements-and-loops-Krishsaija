/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int add(int a, int b){
    return(a+b);
}
int subtract(int a, int b){
    return(a-b);

}
int multiply(int a, int b){
    return(a*b);
}
int divide(int a, int b){
    return(a/b);
}
int main()
{
    int a,b,var,c,d,e;
    printf("give two numbers-");
    scanf("%d %d" ,&a , &b );
    
   var= add(a,b);
   c=subtract(a,b);
   d=multiply(a,b);
   e=divide(a,b);
    printf(" the addition is  %d \n the subtraction is %d \n the multiplication is %d \n the division is %d", var,c,d,e);
}